---
name: veri-tabani
description: "Veritabanı tasarım ve sorgu görevlerinde uzmanlık katmanı sağlar: SQL sorgu optimizasyonu, N+1 problem çözümü, cursor-based pagination, transaction ve lock yönetimi, geri alınabilir migration disiplini, repository/DAO organizasyonu. sql, prisma, db, migration, seed dosyalarında veya şema tasarımı, sorgu performansı, indeks stratejisi, veri bütünlüğü söz konusu olduğunda mutlaka kullanılır."
---

# Veri Tabani

## Genel Bakış

Bu skill, veritabanı görevlerinde uzmanlık katmanı sağlar. SQL sorgu optimizasyonu, N+1 problem çözümü, pagination, transaction ve veri bütünlüğü, migration yönetimi, veritabanına özel güvenlik ve kod organizasyonu kurallarını tanımlar.

> Anayasa (`AGENTS.md`) her zaman önceliklidir; bu skill yalnızca veritabanına özgü uzmanlık katmanı sağlar.

---

## SQL Sorgu Optimizasyonu

* `SELECT *` kullanma; sadece gerekli kolonları seç (`SELECT id, ad, soyad FROM ...`).
* Sorgu içinde subquery yerine uygun `JOIN` türü kullan; `INNER JOIN`, `LEFT JOIN` ihtiyaca göre seç.
* `WHERE` koşullarında indeksli kolonları kullan; fonksiyon tabanlı filtreleme indeks kullanımını bozar.
* `LIKE` sorgularında baştaki wildcard (`%deger`) indeks kullanımını engeller; tam metin arama (full-text search) tercih et.
* Karmaşık sorguları `EXPLAIN` / `EXPLAIN ANALYZE` ile analiz et; execution planı kontrol et.
* Gereksiz `DISTINCT` ve `ORDER BY` kullanma; maliyetli operasyonları minimize et.

## N+1 Sorgu Problemi ve JOIN Stratejisi

* N+1 sorgu problemi oluşturma; döngü içinde sorgu çalıştırma.
* İlişkisel verilerde `JOIN` kullan; tek sorguda tüm ilişkili veriyi çek.
* ORM kullanırken `eager loading` / `with()` / `include` özellikleriyle ilişkileri önceden yükle.
* `EXISTS` / `IN` alt sorgularını uygun senaryolarda kullan; `JOIN` her zaman en iyi seçenek olmayabilir.
* Toplu veri işlemlerinde `batch` işle; her kayıt için ayrı sorgu yerine toplu `INSERT` / `UPDATE` kullan.

## Pagination (Sayfalama)

* Büyük veri setlerinde sayfalama zorunludur; tek sorguda tüm veriyi çekme.
* Offset-based pagination yerine cursor-based pagination tercih et; büyük offset'lerde performans düşer.
* Limit her zaman belirle; `LIMIT` ve `OFFSET` / `WHERE id > cursor` kullan.
* Toplam kayıt sayısını her sorguda hesaplama; gerekiyorsa cache'le.
* Sonsuz kayıt döndüren endpoint oluşturma; maksimum limit zorunlu kıl.

## Transaction ve Veri Bütünlüğü

* Birden fazla tabloyu etkileyen işlemlerde `transaction` kullan; ya hepsi başarılı ya hiçbiri.
* Transaction içinde uzun süren işlemler yapma; lock süresini minimize et.
* `BEGIN` / `COMMIT` / `ROLLBACK` akışını doğru yönet; hata durumunda `ROLLBACK` yap.
* Deadlock riskini azalt; tablo lock sırasını tutarlı tut.
* Optimistic locking veya pessimistic locking ihtiyaca göre kullan; `version` kolonu ile çakışma tespiti yap.

## Migration Yönetimi

* Migration dosyalarını version control'de tut; şema değişiklikleri takip edilebilir olmalı.
* Her migration tek bir değişiklik içermeli; birden fazla değişiklik ayrı migration dosyalarında.
* Migration'lar geri alınabilir (reversible) olmalı; `up` ve `down` yöntemleri tanımlı olmalı.
* Production'da yıkıcı migration (drop column, drop table) dikkatli yap; önce veriyi taşı, sonra düşür.
* Migration sırasına dikkat et; bağımlı migration'lar doğru sırada çalışmalı.
* Veri kaybına yol açabilecek migration'larda kullanıcıyı uyar; onay al.

## Veritabanına Özel Güvenlik

* Veritabanı yetkilendirmesi `role-based` olmalı; her kullanıcı sadece kendi yetkisindeki veriyi görmeli.
* Hassas verinin loglanması ve maskelenmesi Anayasa 8.7'ye göre yürütülür.
* Bağlantı bilgileri ve secret yönetimi Anayasa 8.6'ya göre yürütülür.

## Kod Organizasyonu

* Sorgu mantığı merkezi repository veya DAO (Data Access Object) katmanında toplanmalı; her yere dağıtma.
* ORM kullanılıyorsa model tanımları tek bir yerde tutulmalı; tekrar tanımlama yapma.
* Ham SQL sorguları merkezi bir dosyada veya sorgu builder ile yönetilmeli; SQL üretimi Anayasa 8.2'deki prepared statement kuralına uyar.
* Veritabanı bağlantısı tek bir instance olarak yönetilmeli; her işlemde yeni bağlantı açma.
* Transaction yönetimi merkezi bir servis katmanında olmalı; her fonksiyon kendi transaction'ını yönetmemeli.
